# Description

# Environment

- operating system:
- Python version:
- pycsw version:
- source/distribution
  - [ ] git clone
  - [ ] DebianGIS/UbuntuGIS
  - [ ] PyPI
  - [ ] zip/tar.gz
  - [ ] other (please specify):
- web server
  - [ ] Apache/mod_wsgi
  - [ ] CGI
  - [ ] other (please specify): 

# Steps to Reproduce

# Additional Information
