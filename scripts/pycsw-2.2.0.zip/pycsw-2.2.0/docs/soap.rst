.. _soap:

SOAP
====

pycsw supports handling of SOAP encoded requests and responses as per subclause 10.3.2 of OGC:CSW 2.0.2.  SOAP request examples can be found in ``tests/index.html``.

