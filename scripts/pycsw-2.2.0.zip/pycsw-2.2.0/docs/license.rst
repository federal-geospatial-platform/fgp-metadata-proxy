.. _license:

License
=======

.. include:: ../LICENSE.txt

Documentation
-------------

The documentation is released under the `Creative Commons Attribution 4.0 International (CC BY 4.0)`_ license.

.. _`Creative Commons Attribution 4.0 International (CC BY 4.0)`: http://creativecommons.org/licenses/by/4.0/
