.. _support:

Support
=======

Community
---------

Please see the `Community </community.html>`_ page for information on the pycsw community, getting support, and how to get involved.
